CQ
Copyright (c) 2006 Lee Ungju, Lee Junho


Installation
------------

Run "setup_CQ_beta.exe"
The game based on 3D graphic. You should have 3D accelation card. 


Goal of the Game
----------------

Each stage show the answer that you should correct. On screen 
there is many printing ball with a number. Select ball and make
operation to correct the answer.

As your operation building technique, you would get more CQ score.

+CQ: You should contain factors on your operation.
-CQ: You should prevent factors on your operation.


Controls
--------
Mouse

[CLICK]				select or cancel ball
[MOVE]				If cursor is at corner, container will rotate.

Keyboard

[BACKSPACE]			cancel recent input
[LEFT], [RIGHT], [UP], [DOWN]	rotate container
[Z][X]				zoom in/out
[PRTSC]				screen caption


Background
----------

CQ is developed using many engine. Thanks for them.

Graphic: OGRE 
This is easy, object-oriented, flexible. You can get help 
fastly from huge community.
(http://www.ogre3d.org/)

Audio: fmod
This is licensed under uncommerical purpose.
(http://www.fmod.org)

Install package: Inno Setup
Thie is powerful install packaging program with script based.
Also it is freeware.
(http://www.jrsoftware.org)



Comments/Bug reports/Improvements
---------------------------------

If you have any comments or bug reports feel free to send them
to my e-mail address ehei00001@gmail.com. In case of bug reports
be sure to include any necessary information like logfile,
computer specifications, etc. If you are able to figure out the
error yourself, you can also send a patch.



License
-------

This program is free software; you can redistribute it and/or 
modify it under uncommerical purpose.